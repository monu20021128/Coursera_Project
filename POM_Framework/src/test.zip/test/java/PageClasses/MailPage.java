package PageClasses;

import org.openqa.selenium.WebDriver;

public class MailPage 
{
	WebDriver driver;
	
	MailPage(WebDriver driver){
		this.driver=driver;
	}
	
	
	
}
