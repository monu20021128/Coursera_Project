package PageClasses;

import BaseClasses.RediffBaseClass;

public class MyPortfolioPage extends RediffBaseClass{
	

}
